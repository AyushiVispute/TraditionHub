const NotFound = () => {
  return (
    <div className="text-center mt-20">
      <h1 className="text-3xl font-bold text-red-500">404</h1>
      <p>Page Not Found</p>
    </div>
  );
};

export default NotFound;
